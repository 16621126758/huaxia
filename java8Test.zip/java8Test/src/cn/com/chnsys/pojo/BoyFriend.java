package cn.com.chnsys.pojo;

/**
 * @Class: BoyFriend
 * @description:
 * @Author: hongzhi.zhao
 * @Date: 2019-08-22 14:13
 */
public class BoyFriend{
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
