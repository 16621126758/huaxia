package cn.com.chnsys.Interface;

/**
 * @Class: MyFunction
 * @description:
 * @Author: hongzhi.zhao
 * @Date: 2019-07-29 16:26
 */
public interface MyFunction {
    default  String getName(){
        return "呵呵呵";
    }
}
