package cn.com.chnsys.Interface;

/**
 * @Class: MyClass
 * @description:
 * @Author: hongzhi.zhao
 * @Date: 2019-07-29 16:21
 */
public class MyClass {
    public String getName(){
        return "嘿嘿嘿";
    }
}
