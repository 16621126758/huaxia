package cn.com.chnsys.lambda;

/**
 * @Class: Godeness
 * @description:
 * @Author: hongzhi.zhao
 * @Date: 2019-07-25 11:03
 */
@FunctionalInterface
public interface Godeness {
      String  getName();


}
